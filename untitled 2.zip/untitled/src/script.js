// الرقم السري الرسمي
var schoolPassword = "110981";

// شاشة الدخول
function checkLogin(){
  var input = document.getElementById("passwordInput").value;
  if(input === schoolPassword){
    document.getElementById("loginPage").style.display="none";
    document.getElementById("mainSite").style.display="block";
  }else{
    alert("الرقم السري غير صحيح ❌");
  }
}

// الانتقال بين الأقسام
function showSection(id){
  var sections = document.querySelectorAll(".content");
  for(var i=0; i<sections.length; i++){
    sections[i].style.display="none";
  }
  document.getElementById(id).style.display="block";
}

// الملخصات + النقاط + الترتيب
function addSummary(){
  var name=document.getElementById("studentName").value;
  var book=document.getElementById("bookName").value;
  var summary=document.getElementById("summaryText").value;

  if(name=="" || book=="" || summary==""){
    alert("عبي كل الحقول 💜");
    return;
  }

  var summaries = JSON.parse(localStorage.getItem("summaries")) || [];

  summaries.push({
    name:name,
    book:book,
    summary:summary,
    points:10
  });

  localStorage.setItem("summaries", JSON.stringify(summaries));

  displaySummaries();
  document.getElementById("studentName").value="";
  document.getElementById("bookName").value="";
  document.getElementById("summaryText").value="";
}

// عرض الملخصات + لوحة الشرف
function displaySummaries(){
  var summaryList=document.getElementById("summaryList");
  summaryList.innerHTML="";

  var summaries = JSON.parse(localStorage.getItem("summaries")) || [];

  // الترتيب حسب النقاط
  summaries.sort(function(a,b){ return b.points - a.points; });

  // لوحة الشرف - أعلى 3 طالبات
  var honorBoard = document.getElementById("honorBoard");
  honorBoard.innerHTML = "";
  var top3 = summaries.slice(0,3);
  for(var i=0;i<top3.length;i++){
    honorBoard.innerHTML += (i+1) + ". " + top3[i].name + " - " + top3[i].points + " نقاط<br>";
  }

  // عرض جميع الملخصات
  for(var i=0;i<summaries.length;i++){
    var card=document.createElement("div");
    card.className="card";
    card.innerHTML="<strong>اسم الطالبة:</strong> "+summaries[i].name+
      "<br><strong>الكتاب:</strong> "+summaries[i].book+
      "<br><strong>النقاط:</strong> "+summaries[i].points+
      "<br><p>"+summaries[i].summary+"</p>";
    summaryList.appendChild(card);
  }
}

// معرض الصور محفوظة Local Storage
function addPhoto(){
  var fileInput=document.getElementById("photoInput");
  var file=fileInput.files[0];
  if(!file){ alert("اختاري صورة 💜"); return; }

  var reader = new FileReader();
  reader.onload = function(e){
    var photos = JSON.parse(localStorage.getItem("photos")) || [];
    photos.push(e.target.result);
    localStorage.setItem("photos", JSON.stringify(photos));
    displayPhotos();
  }
  reader.readAsDataURL(file);
  fileInput.value="";
}

// عرض الصور من Local Storage
function displayPhotos(){
  var photoGallery=document.getElementById("photoGallery");
  photoGallery.innerHTML="";
  var photos = JSON.parse(localStorage.getItem("photos")) || [];
  for(var i=0;i<photos.length;i++){
    var img=document.createElement("img");
    img.src=photos[i];
    photoGallery.appendChild(img);
  }
}

// تشغيل عند فتح الموقع
displaySummaries();
displayPhotos();